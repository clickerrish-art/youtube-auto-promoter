import { useState, useEffect, useCallback, useRef } from "react";
import CONFIG from "./config";

// ===== TYPES =====
interface YouTubeVideo {
  id: string;
  title: string;
  thumbnail: string;
  description: string;
  publishedAt: string;
  channelTitle: string;
  viewCount: string;
  likeCount: string;
  duration: string;
  category: string;
}

interface RSSArticle {
  title: string;
  link: string;
  description: string;
  pubDate: string;
  source: string;
  sourceUrl: string;
  category: string;
  thumbnail?: string;
}

interface FeedStatus {
  url: string;
  name: string;
  status: "loading" | "success" | "error";
  articleCount: number;
  lastFetched: string;
}

type TabId = "videos" | "rss" | "sources" | "automation";

// ===== HELPERS =====
const CORS_PROXY = "https://api.allorigins.win/raw?url=";
const YT_API = CONFIG.YOUTUBE_API_KEY;
const CHANNEL_ID = CONFIG.YOUTUBE_CHANNEL_ID;

function formatDuration(iso: string): string {
  if (!iso) return "0:00";
  const m = iso.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
  if (!m) return "0:00";
  const h = m[1] ? `${m[1]}:` : "";
  const min = m[2] ? m[2].padStart(h ? 2 : 1, "0") : "0";
  const sec = m[3] ? m[3].padStart(2, "0") : "00";
  return `${h}${min}:${sec}`;
}

function timeAgo(dateStr: string): string {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  if (days < 30) return `${days}d ago`;
  return `${Math.floor(days / 30)}mo ago`;
}

function categorize(text: string): string {
  const lower = text.toLowerCase();
  for (const cat of CONFIG.CATEGORIES) {
    if (cat.id === "all") continue;
    if (cat.keywords.some((k) => lower.includes(k))) return cat.id;
  }
  return "nature";
}

function formatCount(n: string): string {
  const num = parseInt(n);
  if (isNaN(num)) return "0";
  if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
  if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
  return num.toString();
}

function extractFeedName(url: string): string {
  try {
    const hostname = new URL(url).hostname.replace("www.", "");
    return hostname.split(".")[0].charAt(0).toUpperCase() + hostname.split(".")[0].slice(1);
  } catch {
    return url.slice(0, 30);
  }
}

function stripHtml(html: string): string {
  return html.replace(/<[^>]*>/g, "").trim();
}

// ===== MAIN APP =====
export default function App() {
  // State
  const [videos, setVideos] = useState<YouTubeVideo[]>([]);
  const [articles, setArticles] = useState<RSSArticle[]>([]);
  const [feedStatuses, setFeedStatuses] = useState<FeedStatus[]>([]);
  const [activeTab, setActiveTab] = useState<TabId>("videos");
  const [activeCategory, setActiveCategory] = useState("all");
  const [search, setSearch] = useState("");
  const [playingVideo, setPlayingVideo] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [lastRefresh, setLastRefresh] = useState<Date>(new Date());
  const [nextRefresh, setNextRefresh] = useState<Date>(new Date(Date.now() + CONFIG.REFRESH_INTERVAL_MS));
  const [countdown, setCountdown] = useState("");
  const [autoRunCount, setAutoRunCount] = useState(0);
  const [totalFetchedVideos, setTotalFetchedVideos] = useState(0);
  const [totalFetchedArticles, setTotalFetchedArticles] = useState(0);
  const [showGuide, setShowGuide] = useState(false);
  const countdownRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // ===== FETCH YOUTUBE VIDEOS =====
  const fetchYouTubeVideos = useCallback(async () => {
    const allVideos: YouTubeVideo[] = [];
    try {
      // Fetch from channel uploads
      const chRes = await fetch(
        `https://www.googleapis.com/youtube/v3/channels?part=contentDetails&id=${CHANNEL_ID}&key=${YT_API}`
      );
      const chData = await chRes.json();
      const uploadsPlaylistId =
        chData?.items?.[0]?.contentDetails?.relatedPlaylists?.uploads;

      if (uploadsPlaylistId) {
        const plRes = await fetch(
          `https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&maxResults=50&playlistId=${uploadsPlaylistId}&key=${YT_API}`
        );
        const plData = await plRes.json();
        const videoIds = plData.items?.map((i: any) => i.snippet.resourceId.videoId).filter(Boolean) || [];

        if (videoIds.length > 0) {
          // Fetch stats in batches of 50
          for (let i = 0; i < videoIds.length; i += 50) {
            const batch = videoIds.slice(i, i + 50);
            const statsRes = await fetch(
              `https://www.googleapis.com/youtube/v3/videos?part=statistics,contentDetails&id=${batch.join(",")}&key=${YT_API}`
            );
            const statsData = await statsRes.json();
            for (const item of statsData.items || []) {
              const snippet = plData.items.find(
                (s: any) => s.snippet.resourceId.videoId === item.id
              )?.snippet;
              if (snippet) {
                allVideos.push({
                  id: item.id,
                  title: snippet.title,
                  thumbnail: snippet.thumbnails?.maxres?.url || snippet.thumbnails?.high?.url || snippet.thumbnails?.medium?.url || "",
                  description: snippet.description?.slice(0, 200) || "",
                  publishedAt: snippet.publishedAt,
                  channelTitle: snippet.channelTitle,
                  viewCount: item.statistics?.viewCount || "0",
                  likeCount: item.statistics?.likeCount || "0",
                  duration: formatDuration(item.contentDetails?.duration || ""),
                  category: categorize(snippet.title + " " + snippet.description),
                });
              }
            }
          }
        }
      }

      // Fetch from playlists
      for (const plId of CONFIG.YOUTUBE_PLAYLISTS) {
        try {
          const plRes = await fetch(
            `https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&maxResults=25&playlistId=${plId}&key=${YT_API}`
          );
          const plData = await plRes.json();
          const pVideoIds = plData.items?.map((i: any) => i.snippet.resourceId.videoId).filter(Boolean) || [];
          if (pVideoIds.length > 0) {
            const statsRes = await fetch(
              `https://www.googleapis.com/youtube/v3/videos?part=statistics,contentDetails&id=${pVideoIds.join(",")}&key=${YT_API}`
            );
            const statsData = await statsRes.json();
            for (const item of statsData.items || []) {
              if (!allVideos.find((v) => v.id === item.id)) {
                const snippet = plData.items.find(
                  (s: any) => s.snippet.resourceId.videoId === item.id
                )?.snippet;
                if (snippet) {
                  allVideos.push({
                    id: item.id,
                    title: snippet.title,
                    thumbnail: snippet.thumbnails?.maxres?.url || snippet.thumbnails?.high?.url || snippet.thumbnails?.medium?.url || "",
                    description: snippet.description?.slice(0, 200) || "",
                    publishedAt: snippet.publishedAt,
                    channelTitle: snippet.channelTitle,
                    viewCount: item.statistics?.viewCount || "0",
                    likeCount: item.statistics?.likeCount || "0",
                    duration: formatDuration(item.contentDetails?.duration || ""),
                    category: categorize(snippet.title + " " + snippet.description),
                  });
                }
              }
            }
          }
        } catch (e) {
          console.warn(`Playlist ${plId} fetch error:`, e);
        }
      }
    } catch (e) {
      console.error("YouTube fetch error:", e);
    }

    // Deduplicate
    const unique = Array.from(new Map(allVideos.map((v) => [v.id, v])).values());
    unique.sort((a, b) => new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime());
    return unique;
  }, []);

  // ===== FETCH RSS FEEDS =====
  const fetchRSSFeeds = useCallback(async () => {
    const allArticles: RSSArticle[] = [];
    const statuses: FeedStatus[] = [];

    const feedPromises = CONFIG.RSS_FEEDS.map(async (feedUrl) => {
      const name = extractFeedName(feedUrl);
      const status: FeedStatus = {
        url: feedUrl,
        name,
        status: "loading",
        articleCount: 0,
        lastFetched: new Date().toISOString(),
      };

      try {
        const res = await fetch(`${CORS_PROXY}${encodeURIComponent(feedUrl)}`, {
          signal: AbortSignal.timeout(10000),
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const text = await res.text();

        // Parse XML
        const parser = new DOMParser();
        const doc = parser.parseFromString(text, "text/xml");
        const items = doc.querySelectorAll("item");

        const feedArticles: RSSArticle[] = [];
        items.forEach((item) => {
          const title = item.querySelector("title")?.textContent || "";
          const link = item.querySelector("link")?.textContent || "";
          const desc = item.querySelector("description")?.textContent || "";
          const pubDate = item.querySelector("pubDate")?.textContent || new Date().toISOString();
          const thumbnail =
            item.querySelector("media\\:thumbnail, thumbnail")?.getAttribute("url") ||
            item.querySelector("media\\:content, content")?.getAttribute("url") ||
            item.querySelector("enclosure")?.getAttribute("url") ||
            undefined;

          if (title && link) {
            feedArticles.push({
              title: stripHtml(title),
              link,
              description: stripHtml(desc).slice(0, 300),
              pubDate,
              source: name,
              sourceUrl: feedUrl,
              category: categorize(title + " " + desc),
              thumbnail,
            });
          }
        });

        allArticles.push(...feedArticles);
        status.status = "success";
        status.articleCount = feedArticles.length;
      } catch (e) {
        status.status = "error";
        console.warn(`RSS feed error (${name}):`, e);
      }

      statuses.push(status);
    });

    await Promise.allSettled(feedPromises);
    setFeedStatuses(statuses);

    // Deduplicate by title and sort by date
    const unique = Array.from(new Map(allArticles.map((a) => [a.title, a])).values());
    unique.sort((a, b) => new Date(b.pubDate).getTime() - new Date(a.pubDate).getTime());
    return unique;
  }, []);

  // ===== MAIN FETCH ALL =====
  const fetchAll = useCallback(async () => {
    setLoading(true);
    console.log("🔄 Auto-fetch started at", new Date().toLocaleString());

    const [vids, arts] = await Promise.all([fetchYouTubeVideos(), fetchRSSFeeds()]);

    setVideos(vids);
    setArticles(arts);
    setTotalFetchedVideos((p) => p + vids.length);
    setTotalFetchedArticles((p) => p + arts.length);
    setAutoRunCount((p) => p + 1);
    setLastRefresh(new Date());
    setNextRefresh(new Date(Date.now() + CONFIG.REFRESH_INTERVAL_MS));
    setLoading(false);

    // Save to localStorage
    try {
      localStorage.setItem(
        "naturevue_cache",
        JSON.stringify({
          videos: vids,
          articles: arts,
          timestamp: Date.now(),
          runCount: autoRunCount + 1,
        })
      );
    } catch {}

    console.log("✅ Fetch complete:", vids.length, "videos,", arts.length, "articles");
  }, [fetchYouTubeVideos, fetchRSSFeeds, autoRunCount]);

  // ===== LOAD CACHED DATA =====
  const loadCache = useCallback(() => {
    try {
      const cached = localStorage.getItem("naturevue_cache");
      if (cached) {
        const data = JSON.parse(cached);
        const age = Date.now() - data.timestamp;
        // Use cache if less than 48 hours old
        if (age < CONFIG.REFRESH_INTERVAL_MS && data.videos?.length > 0) {
          setVideos(data.videos);
          setArticles(data.articles || []);
          setAutoRunCount(data.runCount || 0);
          const next = new Date(data.timestamp + CONFIG.REFRESH_INTERVAL_MS);
          setLastRefresh(new Date(data.timestamp));
          setNextRefresh(next);
          return true;
        }
      }
    } catch {}
    return false;
  }, []);

  // ===== COUNTDOWN TIMER =====
  const updateCountdown = useCallback(() => {
    const diff = nextRefresh.getTime() - Date.now();
    if (diff <= 0) {
      setCountdown("Refreshing now...");
      fetchAll();
      return;
    }
    const hrs = Math.floor(diff / 3600000);
    const mins = Math.floor((diff % 3600000) / 60000);
    const secs = Math.floor((diff % 60000) / 1000);
    setCountdown(`${hrs}h ${mins}m ${secs}s`);
  }, [nextRefresh, fetchAll]);

  // ===== EFFECTS =====
  useEffect(() => {
    const hasCache = loadCache();
    if (!hasCache) {
      fetchAll();
    } else {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    countdownRef.current = setInterval(updateCountdown, 1000);
    return () => {
      if (countdownRef.current) clearInterval(countdownRef.current);
    };
  }, [updateCountdown]);

  // ===== FILTERED DATA =====
  const filteredVideos = videos.filter((v) => {
    const matchSearch =
      !search ||
      v.title.toLowerCase().includes(search.toLowerCase()) ||
      v.channelTitle.toLowerCase().includes(search.toLowerCase());
    const matchCat = activeCategory === "all" || v.category === activeCategory;
    return matchSearch && matchCat;
  });

  const filteredArticles = articles.filter((a) => {
    const matchSearch =
      !search ||
      a.title.toLowerCase().includes(search.toLowerCase()) ||
      a.source.toLowerCase().includes(search.toLowerCase());
    const matchCat = activeCategory === "all" || a.category === activeCategory;
    return matchSearch && matchCat;
  });

  const successFeeds = feedStatuses.filter((f) => f.status === "success").length;
  const totalFeeds = feedStatuses.length || CONFIG.RSS_FEEDS.length;

  // ===== TABS =====
  const tabs: { id: TabId; label: string; icon: string; count?: number }[] = [
    { id: "videos", label: "Videos", icon: "🎬", count: videos.length },
    { id: "rss", label: "RSS Feed", icon: "📡", count: articles.length },
    { id: "sources", label: "Sources", icon: "🔌", count: totalFeeds },
    { id: "automation", label: "Auto Status", icon: "🤖" },
  ];

  return (
    <div className="min-h-screen hero-gradient">
      {/* ===== HEADER ===== */}
      <header className="relative overflow-hidden border-b border-white/5">
        {/* Background particles */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          {["🌊","🐋","🦈","🐠","🦅","🌿","🦁","🐘","🦋","🌺","🐳","🦜","🐢","🦩","🐬"].map((emoji, i) => (
            <span
              key={i}
              className="absolute text-2xl opacity-10 animate-float"
              style={{
                left: `${(i * 7) % 100}%`,
                top: `${(i * 13) % 80}%`,
                animationDelay: `${i * 0.4}s`,
                animationDuration: `${5 + (i % 4)}s`,
              }}
            >
              {emoji}
            </span>
          ))}
        </div>

        <div className="relative max-w-7xl mx-auto px-4 py-8 sm:py-12">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-cyan-500 flex items-center justify-center text-xl animate-pulse-glow">
                  🌿
                </div>
                <h1 className="text-3xl sm:text-4xl font-bold bg-gradient-to-r from-emerald-400 via-cyan-400 to-blue-400 bg-clip-text text-transparent">
                  NatureVue
                </h1>
                <span className="px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-400 rounded-full border border-emerald-500/30">
                  Auto
                </span>
              </div>
              <p className="text-slate-400 text-sm max-w-lg">
                Automated wildlife & nature video hub. Runs every <span className="text-emerald-400 font-semibold">48 hours</span>. 
                Fetching from <span className="text-cyan-400 font-semibold">{CONFIG.RSS_FEEDS.length} sources</span>.
              </p>
            </div>

            <div className="flex items-center gap-3">
              {/* Live status indicator */}
              <div className="flex items-center gap-2 px-3 py-2 rounded-lg glass text-xs">
                <div className={`status-dot ${loading ? "loading" : "error"}`} />
                <span className="text-slate-400">
                  {loading ? "Syncing..." : "Live"}
                </span>
              </div>

              {/* Subscribe button */}
              <a
                href={`https://www.youtube.com/channel/${CHANNEL_ID}?sub_confirmation=1`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-4 py-2.5 bg-red-600 hover:bg-red-500 text-white rounded-lg font-semibold text-sm transition-all hover:scale-105 hover:shadow-lg hover:shadow-red-500/25"
              >
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M19.615 3.184c-3.604-.246-11.631-.245-15.23 0C.488 3.45.029 5.804 0 12c.029 6.185.484 8.549 4.385 8.816 3.6.245 11.626.246 15.23 0C23.512 20.55 23.971 18.196 24 12c-.029-6.185-.484-8.549-4.385-8.816zM9 16V8l8 4-8 4z"/>
                </svg>
                Subscribe
              </a>
            </div>
          </div>

          {/* Stats bar */}
          <div className="mt-6 grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { icon: "🎬", label: "Videos", value: videos.length, color: "text-emerald-400" },
              { icon: "📡", label: "Articles", value: articles.length, color: "text-cyan-400" },
              { icon: "🔌", label: "Sources OK", value: `${successFeeds}/${totalFeeds}`, color: "text-blue-400" },
              { icon: "⏱️", label: "Next refresh", value: countdown, color: "text-amber-400" },
            ].map((s, i) => (
              <div key={i} className="flex items-center gap-3 px-4 py-3 rounded-xl glass">
                <span className="text-xl">{s.icon}</span>
                <div>
                  <div className="text-[10px] uppercase tracking-wider text-slate-500">{s.label}</div>
                  <div className={`text-sm font-bold ${s.color}`}>{s.value}</div>
                </div>
              </div>
            ))}
          </div>

          {/* Auto-progress bar */}
          <div className="mt-4">
            <div className="h-1 rounded-full bg-slate-800 overflow-hidden">
              <div
                className="h-full progress-bar rounded-full transition-all duration-1000"
                style={{
                  width: `${Math.max(2, 100 - ((nextRefresh.getTime() - Date.now()) / CONFIG.REFRESH_INTERVAL_MS) * 100)}%`,
                }}
              />
            </div>
            <div className="flex justify-between mt-1 text-[10px] text-slate-600">
              <span>Last: {lastRefresh.toLocaleString()}</span>
              <span>Auto-refresh every {CONFIG.REFRESH_INTERVAL_LABEL}</span>
              <span>Run #{autoRunCount}</span>
            </div>
          </div>
        </div>
      </header>

      {/* ===== MAIN CONTENT ===== */}
      <main className="max-w-7xl mx-auto px-4 py-6">
        {/* Tabs */}
        <div className="flex gap-2 mb-4 overflow-x-auto pb-2">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`tab-btn flex items-center gap-2 px-4 py-2.5 rounded-lg border border-transparent text-sm font-medium whitespace-nowrap ${
                activeTab === tab.id
                  ? "active"
                  : "text-slate-400 hover:text-white hover:bg-white/5"
              }`}
            >
              <span>{tab.icon}</span>
              <span>{tab.label}</span>
              {tab.count !== undefined && (
                <span className="px-1.5 py-0.5 text-[10px] bg-white/10 rounded-full">
                  {tab.count}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Search + Categories (only for videos & rss tabs) */}
        {(activeTab === "videos" || activeTab === "rss") && (
          <div className="mb-6 space-y-3">
            {/* Search */}
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500">🔍</span>
              <input
                type="text"
                placeholder={`Search ${activeTab === "videos" ? "videos" : "articles"}...`}
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full pl-10 pr-4 py-3 rounded-xl glass bg-transparent text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500/30 text-sm"
              />
              {search && (
                <button
                  onClick={() => setSearch("")}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white text-xs"
                >
                  ✕
                </button>
              )}
            </div>

            {/* Category filters */}
            <div className="flex gap-2 overflow-x-auto pb-1">
              {CONFIG.CATEGORIES.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
                    activeCategory === cat.id
                      ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                      : "text-slate-400 hover:text-white bg-white/5 hover:bg-white/10"
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* ===== VIDEOS TAB ===== */}
        {activeTab === "videos" && (
          <>
            {loading && videos.length === 0 ? (
              <LoadingSkeleton type="videos" />
            ) : filteredVideos.length === 0 ? (
              <EmptyState message="No videos found" icon="🎬" />
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                {filteredVideos.map((video, i) => (
                  <div
                    key={video.id}
                    className="video-card rounded-xl overflow-hidden glass cursor-pointer"
                    style={{ animationDelay: `${i * 0.05}s` }}
                    onClick={() => setPlayingVideo(video.id)}
                  >
                    {/* Thumbnail */}
                    <div className="relative aspect-video bg-slate-800">
                      {video.thumbnail ? (
                        <img
                          src={video.thumbnail}
                          alt={video.title}
                          className="w-full h-full object-cover"
                          loading="lazy"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-4xl">🎬</div>
                      )}
                      {/* Play overlay */}
                      <div className="play-overlay absolute inset-0 bg-black/50 flex items-center justify-center">
                        <div className="w-14 h-14 rounded-full bg-red-600 flex items-center justify-center shadow-lg shadow-red-500/30">
                          <svg className="w-6 h-6 text-white ml-1" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M8 5v14l11-7z"/>
                          </svg>
                        </div>
                      </div>
                      {/* Duration badge */}
                      <span className="absolute bottom-2 right-2 px-1.5 py-0.5 bg-black/80 text-white text-[10px] font-mono rounded">
                        {video.duration}
                      </span>
                      {/* Category badge */}
                      <span className="absolute top-2 left-2 px-2 py-0.5 bg-emerald-500/80 text-white text-[10px] font-bold uppercase rounded-full">
                        {video.category}
                      </span>
                    </div>
                    {/* Info */}
                    <div className="p-3">
                      <h3 className="text-sm font-semibold text-white line-clamp-2 leading-tight mb-2">
                        {video.title}
                      </h3>
                      <div className="flex items-center justify-between text-[11px] text-slate-500">
                        <span>👁 {formatCount(video.viewCount)} views</span>
                        <span>👍 {formatCount(video.likeCount)}</span>
                        <span>{timeAgo(video.publishedAt)}</span>
                      </div>
                      <div className="mt-1.5 text-[11px] text-slate-600 truncate">
                        {video.channelTitle}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </>
        )}

        {/* ===== RSS TAB ===== */}
        {activeTab === "rss" && (
          <>
            {loading && articles.length === 0 ? (
              <LoadingSkeleton type="articles" />
            ) : filteredArticles.length === 0 ? (
              <EmptyState message="No articles found" icon="📡" />
            ) : (
              <div className="space-y-2">
                {filteredArticles.slice(0, 100).map((article, i) => (
                  <a
                    key={i}
                    href={article.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="rss-card block p-4 rounded-xl glass border-l-2 border-l-transparent"
                  >
                    <div className="flex items-start gap-3">
                      <div className="flex-1 min-w-0">
                        <h3 className="text-sm font-semibold text-white line-clamp-2 mb-1">
                          {article.title}
                        </h3>
                        {article.description && (
                          <p className="text-xs text-slate-500 line-clamp-2 mb-2">
                            {article.description}
                          </p>
                        )}
                        <div className="flex items-center gap-3 text-[10px] text-slate-600">
                          <span className="px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 font-medium">
                            {article.source}
                          </span>
                          <span className="px-2 py-0.5 rounded-full bg-white/5 uppercase font-bold">
                            {article.category}
                          </span>
                          <span>{timeAgo(article.pubDate)}</span>
                        </div>
                      </div>
                      {article.thumbnail && (
                        <img
                          src={article.thumbnail}
                          alt=""
                          className="w-20 h-16 rounded-lg object-cover flex-shrink-0"
                          loading="lazy"
                        />
                      )}
                    </div>
                  </a>
                ))}
                {filteredArticles.length > 100 && (
                  <div className="text-center py-4 text-slate-500 text-sm">
                    Showing 100 of {filteredArticles.length} articles. Use search to narrow results.
                  </div>
                )}
              </div>
            )}
          </>
        )}

        {/* ===== SOURCES TAB ===== */}
        {activeTab === "sources" && (
          <div className="space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {feedStatuses.length === 0
                ? CONFIG.RSS_FEEDS.map((url, i) => (
                    <div key={i} className="p-3 rounded-xl glass flex items-center gap-3">
                      <div className="status-dot loading" />
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-medium text-white truncate">{extractFeedName(url)}</div>
                        <div className="text-[10px] text-slate-600 truncate">{url}</div>
                      </div>
                      <span className="text-[10px] text-amber-400">Pending</span>
                    </div>
                  ))
                : feedStatuses
                    .sort((a, b) => b.articleCount - a.articleCount)
                    .map((feed, i) => (
                      <div key={i} className="p-3 rounded-xl glass flex items-center gap-3">
                        <div className={`status-dot ${feed.status}`} />
                        <div className="flex-1 min-w-0">
                          <div className="text-sm font-medium text-white truncate">{feed.name}</div>
                          <div className="text-[10px] text-slate-600 truncate">{feed.url}</div>
                        </div>
                        <div className="text-right flex-shrink-0">
                          <div className="text-sm font-bold text-emerald-400">{feed.articleCount}</div>
                          <div className="text-[9px] text-slate-600">
                            {feed.status === "success" ? "✅ OK" : feed.status === "loading" ? "⏳" : "❌ Fail"}
                          </div>
                        </div>
                      </div>
                    ))}
            </div>
            {feedStatuses.length > 0 && (
              <div className="grid grid-cols-3 gap-3 mt-4">
                <div className="p-4 rounded-xl glass text-center">
                  <div className="text-2xl font-bold text-emerald-400">{successFeeds}</div>
                  <div className="text-xs text-slate-500">Working</div>
                </div>
                <div className="p-4 rounded-xl glass text-center">
                  <div className="text-2xl font-bold text-red-400">
                    {feedStatuses.filter((f) => f.status === "error").length}
                  </div>
                  <div className="text-xs text-slate-500">Failed</div>
                </div>
                <div className="p-4 rounded-xl glass text-center">
                  <div className="text-2xl font-bold text-cyan-400">
                    {feedStatuses.reduce((sum, f) => sum + f.articleCount, 0)}
                  </div>
                  <div className="text-xs text-slate-500">Total Articles</div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ===== AUTOMATION TAB ===== */}
        {activeTab === "automation" && (
          <div className="space-y-4">
            {/* Status dashboard */}
            <div className="p-6 rounded-2xl glass">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-500 to-cyan-500 flex items-center justify-center text-2xl animate-pulse-glow">
                  🤖
                </div>
                <div>
                  <h2 className="text-xl font-bold text-white">Automation Dashboard</h2>
                  <p className="text-sm text-slate-400">Your app runs on autopilot</p>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
                {[
                  { label: "Status", value: loading ? "⏳ Syncing" : "✅ Active", color: loading ? "text-amber-400" : "text-emerald-400" },
                  { label: "Cycle", value: CONFIG.REFRESH_INTERVAL_LABEL, color: "text-cyan-400" },
                  { label: "Total Runs", value: `#${autoRunCount}`, color: "text-blue-400" },
                  { label: "Next Run", value: countdown, color: "text-amber-400" },
                ].map((s, i) => (
                  <div key={i} className="p-4 rounded-xl bg-slate-800/50 text-center">
                    <div className="text-[10px] uppercase tracking-wider text-slate-600 mb-1">{s.label}</div>
                    <div className={`text-lg font-bold ${s.color}`}>{s.value}</div>
                  </div>
                ))}
              </div>

              {/* Timeline */}
              <div className="space-y-2">
                <h3 className="text-sm font-semibold text-slate-400 mb-2">📋 Activity Log</h3>
                {[
                  { time: new Date().toLocaleString(), event: "Page loaded / viewing dashboard", icon: "👀" },
                  ...(lastRefresh.getTime() > 0
                    ? [{ time: lastRefresh.toLocaleString(), event: `Fetched ${videos.length} videos + ${articles.length} articles from ${CONFIG.RSS_FEEDS.length} sources`, icon: "📡" }]
                    : []),
                  { time: "—", event: "App deployed to GitHub Pages", icon: "🚀" },
                  { time: "—", event: "GitHub Actions workflow active (runs every 48h)", icon: "⚙️" },
                ].map((log, i) => (
                  <div key={i} className="flex items-start gap-3 p-3 rounded-lg bg-slate-800/30">
                    <span className="text-lg">{log.icon}</span>
                    <div className="flex-1">
                      <div className="text-sm text-white">{log.event}</div>
                      <div className="text-[10px] text-slate-600">{log.time}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Manual actions */}
            <div className="p-6 rounded-2xl glass">
              <h3 className="text-lg font-bold text-white mb-4">⚡ Manual Controls</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button
                  onClick={fetchAll}
                  disabled={loading}
                  className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/30 transition-all disabled:opacity-50 font-medium text-sm"
                >
                  {loading ? (
                    <span className="animate-spin-slow">⏳</span>
                  ) : (
                    <span>🔄</span>
                  )}
                  {loading ? "Fetching..." : "Force Refresh Now"}
                </button>
                <button
                  onClick={() => {
                    localStorage.removeItem("naturevue_cache");
                    window.location.reload();
                  }}
                  className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-red-500/10 text-red-400 border border-red-500/20 hover:bg-red-500/20 transition-all font-medium text-sm"
                >
                  🗑️ Clear Cache & Reload
                </button>
              </div>
            </div>

            {/* Deployment guide */}
            <div className="p-6 rounded-2xl glass">
              <button
                onClick={() => setShowGuide(!showGuide)}
                className="flex items-center gap-2 text-lg font-bold text-white mb-0 w-full"
              >
                <span>{showGuide ? "▼" : "▶"}</span>
                📘 Deploy to GitHub Pages (Step by Step)
              </button>
              {showGuide && (
                <div className="mt-4 space-y-4 text-sm">
                  <GuideStep
                    step={1}
                    title="Create a GitHub account"
                    desc="Go to github.com and sign up (it's free). Then create a new repository called 'naturevue'."
                  />
                  <GuideStep
                    step={2}
                    title="Download this project"
                    desc="Click the download button to get all the files. Extract them to a folder on your computer."
                  />
                  <GuideStep
                    step={3}
                    title="Add your YouTube API key"
                    desc="Go to your repo → Settings → Secrets → Actions → New secret. Name it VITE_YOUTUBE_API_KEY. Paste your key: AIzaSyCSRL94cywM-QuNPFJOEaMl-NmUJRTXgVs"
                  />
                  <GuideStep
                    step={4}
                    title="Push the code to GitHub"
                    desc={`Open terminal/command prompt in the project folder and run:\ngit init\ngit add .\ngit commit -m "Deploy NatureVue"\ngit branch -M main\ngit remote add origin https://github.com/YOURUSERNAME/naturevue.git\ngit push -u origin main`}
                  />
                  <GuideStep
                    step={5}
                    title="Enable GitHub Pages"
                    desc="Go to your repo → Settings → Pages → Source → select 'GitHub Actions'. The deploy.yml workflow will automatically build and deploy your site."
                  />
                  <GuideStep
                    step={6}
                    title="Set it to auto-run every 48 hours"
                    desc="The workflow is already configured! It runs every 48 hours automatically via the cron schedule. You can also manually trigger it from the Actions tab."
                  />
                  <GuideStep
                    step={7}
                    title="Share your site!"
                    desc="Your site will be live at https://YOURUSERNAME.github.io/naturevue/ — share this link everywhere to get views!"
                  />
                </div>
              )}
            </div>
          </div>
        )}
      </main>

      {/* ===== VIDEO PLAYER MODAL ===== */}
      {playingVideo && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4 modal-overlay"
          onClick={() => setPlayingVideo(null)}
        >
          <div
            className="relative w-full max-w-4xl aspect-video rounded-2xl overflow-hidden shadow-2xl shadow-emerald-500/10"
            onClick={(e) => e.stopPropagation()}
          >
            <iframe
              src={`https://www.youtube.com/embed/${playingVideo}?autoplay=1&rel=0`}
              title="YouTube video player"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              className="w-full h-full"
            />
            <button
              onClick={() => setPlayingVideo(null)}
              className="absolute -top-10 right-0 text-white hover:text-red-400 text-sm font-medium flex items-center gap-1"
            >
              ✕ Close
            </button>
          </div>
        </div>
      )}

      {/* ===== FOOTER ===== */}
      <footer className="border-t border-white/5 mt-12 py-8">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-2 mb-3">
            <span className="text-lg">🌿</span>
            <span className="text-sm font-bold bg-gradient-to-r from-emerald-400 to-cyan-400 bg-clip-text text-transparent">
              NatureVue
            </span>
            <span className="text-xs text-slate-600">v2.0</span>
          </div>
          <p className="text-xs text-slate-600 max-w-md mx-auto mb-3">
            Automated nature & wildlife video hub. Refreshes every 48 hours.
            Powered by YouTube Data API + {CONFIG.RSS_FEEDS.length} RSS feeds.
          </p>
          <div className="flex items-center justify-center gap-4 text-xs text-slate-700">
            <span>🎬 {totalFetchedVideos} videos fetched</span>
            <span>•</span>
            <span>📡 {totalFetchedArticles} articles indexed</span>
            <span>•</span>
            <span>🤖 {autoRunCount} auto-runs</span>
          </div>
        </div>
      </footer>
    </div>
  );
}

// ===== SUB-COMPONENTS =====

function LoadingSkeleton({ type }: { type: "videos" | "articles" }) {
  return (
    <div className={type === "videos" ? "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4" : "space-y-2"}>
      {Array.from({ length: type === "videos" ? 8 : 10 }).map((_, i) => (
        <div key={i} className={`${type === "videos" ? "rounded-xl" : "rounded-xl p-4"} glass animate-shimmer`}>
          {type === "videos" ? (
            <>
              <div className="aspect-video bg-slate-800/50 rounded-t-xl" />
              <div className="p-3 space-y-2">
                <div className="h-3 bg-slate-800/50 rounded w-4/5" />
                <div className="h-3 bg-slate-800/50 rounded w-3/5" />
                <div className="h-2 bg-slate-800/50 rounded w-2/5" />
              </div>
            </>
          ) : (
            <div className="space-y-2">
              <div className="h-3 bg-slate-800/50 rounded w-3/4" />
              <div className="h-2 bg-slate-800/50 rounded w-full" />
              <div className="h-2 bg-slate-800/50 rounded w-1/2" />
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

function EmptyState({ message, icon }: { message: string; icon: string }) {
  return (
    <div className="text-center py-20">
      <div className="text-5xl mb-4">{icon}</div>
      <div className="text-slate-400 text-lg font-medium">{message}</div>
      <div className="text-slate-600 text-sm mt-1">Try adjusting your search or filters</div>
    </div>
  );
}

function GuideStep({ step, title, desc }: { step: number; title: string; desc: string }) {
  return (
    <div className="flex gap-4 p-4 rounded-xl bg-slate-800/30">
      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-sm">
        {step}
      </div>
      <div>
        <div className="font-semibold text-white mb-1">{title}</div>
        <div className="text-slate-400 whitespace-pre-line text-xs leading-relaxed">{desc}</div>
      </div>
    </div>
  );
}
