// 🔄 AUTOMATION CONFIG — All settings in one place
// Change these values to customize the app

const CONFIG = {
  // ===== YOUR YOUTUBE CHANNEL =====
  YOUTUBE_CHANNEL_ID: "UC41xXhw22o6Q2I2pTKB2kOg",
  YOUTUBE_API_KEY: "AIzaSyCSRL94cywM-QuNPFJOEaMl-NmUJRTXgVs",
  YOUTUBE_PLAYLISTS: [
    "PLhErNUuDxs_2F8ayJ_XDrgCbH-CiAqRcd",
    "PLhErNUuDxs_04gGg-HoaSkXNQ1bno89I8",
    "PLhErNUuDxs_0OFY1a8itinxcWutV7oN78",
    "PLhErNUuDxs_3s5P3kfBg1wZdWJY_PmAfC",
  ],

  // ===== AUTO-REFRESH INTERVAL =====
  // 172800000ms = 48 hours | 600000 = 10 min (for testing)
  REFRESH_INTERVAL_MS: 172800000,
  REFRESH_INTERVAL_LABEL: "48 hours",

  // ===== RSS FEEDS (44 sources) =====
  RSS_FEEDS: [
    "https://www.nationalgeographic.com/animals/rss",
    "https://www.bbcearth.com/feed/",
    "https://www.worldwildlife.org/feeds/news",
    "https://www.discovery.com/nature/rss",
    "https://africageographic.com/feed/",
    "https://www.krugerpark.co.za/feed/",
    "https://www.animalplanet.com/feed",
    "https://www.audubon.org/rss",
    "https://blog.nationalgeographic.org/feed/",
    "https://www.earthtouchnews.com/feed/",
    "https://www.treehugger.com/animals-wildlife-4127792/feed",
    "https://www.oceana.org/feed/",
    "https://www.smithsonianmag.com/rss/animals/",
    "https://www.sciencedaily.com/rss/plants_animals.xml",
    "https://phys.org/rss-feed/biology-news/plants-animals/",
    "https://www.cornelllab.org/feed/",
    "https://blog.wildlife.state.nh.us/feed/",
    "https://www.fws.gov/news/rss.xml",
    "https://www.nps.gov/feeds/news.rss",
    "https://www.nature.com/subjects/animals.rss",
    "https://www.sciencenews.org/topic/animals/feed",
    "https://www.livescience.com/feeds/animals",
    "https://news.mongabay.com/feed/",
    "https://www.wildlifeonline.me.uk/feed/",
    "https://africafreak.com/feed",
    "https://www.africanconservation.org/feed",
    "https://safarisafricana.com/feed/",
    "https://latestsightings.com/feed/",
    "https://www.krugerpark.co.za/Kruger_National_Park_Wildlife-travel/kruger-park-wildlife-blog.html/feed",
    "https://wildambience.com/feed/",
    "https://www.outofafricapark.com/feed/",
    "https://www.animalspot.net/feed/",
    "https://www.bioexpedition.com/feed/",
    "https://facts.net/category/nature/animals/feed/",
    "https://a-z-animals.com/feed/",
    "https://www.worldatlas.com/animals/feed",
    "https://www.activewild.com/feed/",
    "https://www.onekindplanet.org/feed/",
    "https://kids.nationalgeographic.com/feed",
    "https://www.theanimalfacts.com/feed/",
    "https://www.animalwised.com/feed/",
    "https://animaldiversity.org/feed/",
    "https://www.biologicaldiversity.org/news/feed/",
    "https://www.conservationinstitute.org/feed/",
    "https://rainforest-alliance.org/feed/",
    "https://www.janegoodall.org/feed/",
    "https://blog.wcs.org/feed/",
  ],

  // ===== CATEGORIES FOR FILTERING =====
  CATEGORIES: [
    { id: "all", label: "🌍 All", keywords: [] },
    { id: "ocean", label: "🌊 Ocean", keywords: ["ocean", "sea", "marine", "whale", "dolphin", "shark", "fish", "coral", "reef", "underwater", "coast", "beach"] },
    { id: "wildlife", label: "🦁 Wildlife", keywords: ["wildlife", "safari", "africa", "kruger", "predator", "hunt", "jungle", "endangered", "conservation", "reserve"] },
    { id: "animals", label: "🐾 Animals", keywords: ["animal", "pet", "dog", "cat", "bird", "elephant", "lion", "tiger", "bear", "monkey", "snake", "penguin"] },
    { id: "nature", label: "🌿 Nature", keywords: ["nature", "forest", "tree", "plant", "flower", "mountain", "river", "lake", "ecosystem", "habitat", "biodiversity"] },
    { id: "science", label: "🔬 Science", keywords: ["science", "research", "study", "discovery", "species", "fossil", "evolution", "dna", "biology"] },
  ],
};

export default CONFIG;
