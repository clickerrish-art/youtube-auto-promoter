# NatureVue — Automated Wildlife Video Hub 🌊🦁

Auto-deploying nature video discovery app that runs every 48 hours.

## 🚀 Quick Deploy to GitHub Pages

### Step 1: Push to GitHub
```bash
git init
git add .
git commit -m "Initial deploy - NatureVue"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git push -u origin main
```

### Step 2: Enable GitHub Pages
1. Go to your repo → **Settings** → **Pages**
2. Source: Select **GitHub Actions**
3. Done! It auto-deploys every 48 hours

### Step 3: Add YouTube API Key (Important!)
1. Go to repo → **Settings** → **Secrets and variables** → **Actions**
2. Click **New repository secret**
3. Name: `VITE_YOUTUBE_API_KEY`
4. Value: `AIzaSyCSRL94cywM-QuNPFJOEaMl-NmUJRTXgVs`
5. Click **Add secret**

### Step 4: Watch it go!
- Your site will be live at: `https://YOUR_USERNAME.github.io/YOUR_REPO/`
- It rebuilds and redeploys **every 48 hours automatically**
- You can also manually trigger it from **Actions** tab → **Run workflow**

## 🔄 Automation Schedule
- ⏰ Every 48 hours (2 days) at midnight UTC
- 🔀 Every time you push code to `main`
- 🖱️ Manual trigger from GitHub Actions tab

## 📡 Connected Sources
- 1 YouTube channel (UC41xXhw22o6Q2I2pTKB2kOg)
- 44 nature/wildlife RSS feeds
- Auto-fetches latest content on every deploy

## 📊 Features
- Auto-fetch YouTube videos
- Auto-pull RSS articles from 44 sources  
- 48-hour auto-refresh cycle
- Search & filter by category
- Embedded YouTube player (real views!)
- Subscribe button (real subscribers!)
- 100% free, no backend needed
